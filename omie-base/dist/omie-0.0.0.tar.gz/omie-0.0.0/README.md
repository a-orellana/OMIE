\# gestionatr
\[!\[Tests\](https://github.com/gisce/gestionatr/actions/workflows/python-app.yml/badge.svg)\](https://github.com/gisce/gestionatr/actions/workflows/python-app.yml)

Librería para la interacción con OMIE desde ERP
